import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by Helen on 04/12/2016.
 */
public class TunerDirectoryTest {
    @Test
    public void addTuner() throws Exception {

    }

    @Test
    public void getTuner() throws Exception {

    }

    @Test
    public void search() throws Exception {

    }

}