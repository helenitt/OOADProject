import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by Helen on 04/12/2016.
 */
public class TunerTest {
    @Test
    public void getName() throws Exception {

    }

    @Test
    public void getLocation() throws Exception {

    }

    @Test
    public void getPhone() throws Exception {

    }

    @Test
    public void getRating() throws Exception {

    }

    @Test
    public void mathches() throws Exception {

    }

}