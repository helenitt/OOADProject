/**
 * Created by Helen on 21/11/2016.
 * Enum Class for Rating - Value Safety
 */
public enum Rating {
    EXCELLENT, GOOD, MODERATE, BAD
}
