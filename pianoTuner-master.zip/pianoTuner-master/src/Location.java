/**
 * Created by Helen on 21/11/2016.
 * Enum Class for Location - Value Safety
 */
public enum Location {
    DINGLE, KILLARNEY, TRALEE
}
